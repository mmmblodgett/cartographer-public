#include "cartographer.h"

int main ()
{
    srand(time(0));

    vector<Tile> tiles = initTiles();
    Tile *currentTile = &tiles[0];
    Tile *nextTile = nullptr;
    Tile *prevTile = nullptr;
    char selection;
    int nextEast;
    int nextNorth;

    int inv[UNIQUE_ITEMS] = {};

    while (true)
    {
        cout << "loop started\n";
        cout << currentTile->getName();
        if(!tileFunction(currentTile, inv))
        {
            currentTile = prevTile;
            continue;
        }
        selection = userInput();
        nextEast = currentTile->m_east;
        nextNorth = currentTile->m_north;
        nextAddress(nextEast, nextNorth, selection);
        nextTile = getByAddress(nextEast, nextNorth, tiles);
        if (!nextTile)
        {
            tiles.push_back(Tile(nextEast, nextNorth));
            nextTile = &tiles.back();
        }
        prevTile = currentTile;
        currentTile = nextTile;
    }

}