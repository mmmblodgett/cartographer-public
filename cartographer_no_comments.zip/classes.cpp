#include "cartographer.h"

void TileType::display() const
{
    cout << m_text << endl;
}

string TileType::getName() const
{
    return m_name;
}

Tile::Tile()
{
    m_type = TileType("home", "You are home by your little cottage");
    m_east = 0;
    m_north = 0;
}

Tile::Tile(int east, int north, TileType type)
{
    m_east = east;
    m_north = north;
    m_type = type;
}

void Tile::display() const
{
    m_type.display();
}

string Tile::getAddress() const
{
    return to_string(m_east) + ", " + to_string(m_north);
}

string Tile::getName() const
{
    return m_type.getName();
}

void Tile::setName(string name)
{
    m_type.m_name = name;
}