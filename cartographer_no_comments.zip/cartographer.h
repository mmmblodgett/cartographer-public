#pragma once

#include <iostream>
#include <cmath>
#include <vector>
#include "mastermind.h"

using namespace std;
const int DIE_SIDES = 115;
const int UNIQUE_ITEMS = 5;
const int RAFT_PRICE = 8;
const int BOOTS_PRICE = 5;
const int ROPES_PRICE = 5;
const int LANTERN_PRICE = 9;
enum Inventory {gold, raft, boots, ropes, lantern};

bool validIn(char in);
char userInput();
void nextAddress(int &east, int &north, char selection);
void pressToContinue();
void shop(int inv[]);
void buy(int inv[], Inventory item, int price, string itemName);

class TileType {
    string m_name;
    string m_text;
public:
    TileType(string name="", string text=""):m_name(name), m_text(text) {}
    void display() const;
    string getName() const;
    friend class Tile;
};

TileType getType();

class Tile {
    TileType m_type;
public:
    int m_north;
    int m_east;
    Tile();
    Tile(int east, int north, TileType type=getType());
    void display() const;
    string getAddress() const;
    string getName() const;
    void setName(string name);
};

Tile* getByAddress(int east, int north, vector<Tile> &tiles);
bool tileFunction(Tile *current, int inv[]);
vector<Tile> initTiles();
bool impasse(Tile *current, int inv[], bool haveTools);